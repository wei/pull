---
name: "⚙️ Change configuration"
about: Do you have a suggestion for changing the configuration, e.g. allow additional licenses or adjust minimal stars?
title: ''
labels: 'configuration'
assignees: ''

---

**Configuration Change:**

<!-- Describe your suggested configuration change. -->
